#include <iostream>
using namespace std;

#define NEWLINE '\n'
#define PREPROCESSOR '\t'


int main() {
    const int LENGTH = 10;
    const int WIDTH = 5;
    const string verticalTab = "\v";
    int area;

    area = LENGTH * WIDTH;
    cout << "Area: ";
    cout << PREPROCESSOR;
    cout << verticalTab;
    cout << area;
    return 0;
}