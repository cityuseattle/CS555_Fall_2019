#include <iostream>
using namespace std;

int main() {
    int i;
    i = 4294967295;
    cout << i << endl;
    return 0;
}