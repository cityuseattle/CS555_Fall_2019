#include <iostream>
using namespace std;

//template for generic type
template<typename K, typename V>

//Hashnode class
class HashNode
{
    public:
    V value;
    K key;

    //constructor of hashnode
    HashNode(K key, V value)
    {
        this->value = value;
        this->key = key;
    }
};

//template for generic type
template<typename K, typename V>

//our own hashmap class
class HashMap
{
    //hash element array
    HashNode<K, V> **arr;
    int capacity;
    //current size
    int size;
    //dummy node
    HashNode<K, V> *dummy;

    public:
    HashMap()
    {
        //Initial capacity of hash array
        capacity = 20;
        size = 0;
        arr = new HashNode<K,V>*[capacity];

        //dummy node with value and key -1
        for(int i=0 ; i < capacity ; i++)
            arr[i] = NULL;

    //dummy node with value and key -1
    dummy = new HashNode<K,V>(-1, -1);
    }
    //This implements hash function to find index for a key
    int hashCode(K key)
    {
        return key % capacity;
    }

    //Function to add key pair
void insertNode(K key, V value)
{
    HashNode<K,V> *temp = new HashNode<K,V>(key, value);

    //Apply hash function to find index for given key
    int hashIndex = hashCode(key);

    //find next free space
    while(arr[hashIndex]) != NULL && arr[hashIndex]->Key != key
        && arr[hashIndex]->key != -1
        {
            hashIndex++;
            hashIndex %= capacity;
        }

        //if new node to be inserted increase size
        if(arr[hashIndex] == NULL || arr[hashIndex]-> == -1)
        size++;
        arr[hashIndex] = temp;
}
//function to delete key value pair
V deleteNode(int key)
{
    //apply hash function to find index for given key
    int hashIndex = hashCode(key);

    //finding the node with given key
    while(arr[hashIndex] != NULL)
    {
        if(arr[hashIndex]->key == key)
        {
            HashNode<K,V> *temp = arr[hashIndex];

            //insert dummy node here for further use
            arr[harshIndex] = dummy;

            //reduce size
            size--;
            return temp->value;
        }
        hashIndex++;
        hashIndex %= capacity;
    }
    //f not found return null
    retun NULL;
}

//function to search value for a given key
V get(int key)
{
    //apply hash function to find index for given key
    int hashIndex = hashCode(key);
    int counter = 0;
    //finding node with given key
    while(arr[hashIndex] != NULL)
    {
        int counter = 0;
        if(counter++>capacity)
            return NULL;

            if(arr[hashIndex]->key==key)
                return arr[hashIndex]->value;
            hashIndex++;
            hashIndex %= capacity;
    }

    //if not found return null
    return NULL;
}

int sizeofMap()
{
    return size;
}

//return true if size is 0
bool isEmpty()
{
    return size == 0;
}

//function to display the stores key value pairs
void display()
{
    for(int i=0 ; i<capacity ; i++)
    {
        if(arr[i] != NULL && arr[i]->key != -1)
            cout << "key = " << arr[i]->key
                <<" value = " << arr[i]->value << endl;
    }
}
};

//driver method to test map class
int main()
{
    HashMap<int, int> *h = new HashMap<int, int>;
    h->insertNode(1,1);
    h->insertNode(2,2);
    h->insertNode(2,3);
    h->display();
    cout << h->sizeofMap() << endl;
    cout << h->deleteNode(2) << endl;
    cout << h->sizeofMap() << endl;
    cout << h->isEmpty() << endl;
    cout << h->get(2);
    cout << endl;
    return 0;
}