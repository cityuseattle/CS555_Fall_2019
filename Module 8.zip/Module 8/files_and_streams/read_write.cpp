#include <iostream>
#include <fstream>
using namespace std;

int main() {
    char data[100];

    //open a file in write mode
    ofstream outfile;
    outfile.open("afile.dat");

    cout << "Writing to the file" << endl;
    cout << "Enter your name: ";
    cin.getline(data, 100);

    //write inputted data to file
    outfile << data << endl;

    cout << "Enter your age: ";
    cin >> data;
    cin.ignore();

    //write inputted data again
    outfile << data << endl;

    //close opened file
    outfile.close();

    //open a file in read mode
    ifstream infile;
    infile.open("afile.dat");

    cout << "Reading from the file" << endl;
    infile >> data;

    //write data at the screen
    cout << data << endl;

    //read data again from file
    infile >> data;
    cout << data << endl;

    //close opened file
    infile.close();

    return 0;
}